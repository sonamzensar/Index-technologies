import React, { Component } from 'react';
import styled, { css } from 'styled-components'



export default class UnsaveDataPopup extends Component {
    constructor(props) {
        super(props);
        this.state = {
      Text: 'YOUR DATA IS SAVED SUCCESSFULLY'
    }
    }

    closePopup = (event) => {

        this.props.history.push('/')
        console.log('agdsagdjsagjd')
    }


    render() {
        const FirstName = this.props.location.state.FirstName;
        const LastName = this.props.location.state.LastName;
        const EmailId = this.props.location.state.EmailId;
        const Password = this.props.location.state.Password;
        const BirthDate = this.props.location.state.BirthDate;

        const Button = styled.button`
border-radius: 3px;
 margin: 0.5em 1em;
padding: 0.25em 1em;
 position: relative;
 left: 300px;
 top: 25px;
      `;

        return (
            <div className='popup' >
                <div className='popup_inner'>
                     <h3>{this.state.Text}</h3>
                    <p>{FirstName}</p>
                    <h6>{LastName}</h6>
                    <h6>{EmailId}</h6>
                    <h6>{Password}</h6>
                    <h6>{BirthDate}</h6>
                    <Button onClick={this.closePopup}>close me</Button>
                </div>
            </div>
        );
    }
}

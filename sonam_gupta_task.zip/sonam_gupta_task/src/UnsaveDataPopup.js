import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import styled, { css } from 'styled-components'
import './App.css';



export default class UnsaveDataPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Text: 'CONFIRMATION'
    }
  }

  closePopup = (event) => {

    this.props.history.push('/')
    console.log('agdsagdjsagjd')
  }
  
  render() {
     const FirstName = this.props.location.state.FirstName;
        const LastName = this.props.location.state.LastName;
        const EmailId = this.props.location.state.EmailId;
        const Password = this.props.location.state.Password;
        const BirthDate = this.props.location.state.BirthDate;

    const Button = styled.button`
  background: grey;
  border-radius: 3px;
  border: 2px solid grey;
  color: white;
  margin: 0.5em 1em;
  padding: 0.25em 1em;
   position: relative;
    left: 249px;
      top: 95px


  ${props => props.primary && css`
     border: 2px solid skyblue;
    background: skyblue;
    color: white;
    position: relative;
    left: 225px;
    top: 95px
  `}
`;

  
    return (
      <div className='popup' ref={filter => this.filter = filter} >
        <div className='popup_inner'>
          <h1>{this.state.Text}</h1>
          <h6>Do you want save changes you made to document before closing ?</h6>
          <p>if you donot save,your changes will lost</p>
          <Button onClick={this.closePopup}>Close me</Button>

            <Link to={{pathname:"/SaveDataPopup",state:{FirstName:FirstName, LastName:LastName, EmailId:EmailId,Password:Password,BirthDate:BirthDate}}}><Button  primary >Save changes</Button></Link>

        </div>
      </div>
    );
  }
}

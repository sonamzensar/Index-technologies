import React, { Component } from 'react';
import { FilePond } from 'react-filepond';
import 'filepond/dist/filepond.min.css';
import './App.css';



export default class AppDragDropDemo extends Component {

    render() {

        return (
            <div className="App">
                <header className="App-header">
                    <h1 className="App-title">Hi,we can add some file through browse or drag&drop!!</h1>
                </header>
              <FilePond allowMultiple={true}/>
            </div>
        );
    }
}
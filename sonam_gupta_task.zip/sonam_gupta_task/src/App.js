import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import styled, { css } from 'styled-components'
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      FirstName: 'Sonam',

      LastName: 'Gupta',

      EmailId: 'sonamgupta.1dec@gmail.com',

      Password: '123456789',

      BirthDate: '01/12/1994',

    };
   
  }
  handleChange1 = (event) => {
    this.setState({ FirstName: event.target.value });
  }
  handleChange2 = (event) => {

    this.setState({ LastName: event.target.value });
  }
  handleChange3 = (event) => {

    this.setState({ EmailId: event.target.value });
  }
  handleChange4 = (event) => {

    this.setState({ Password: event.target.value });
  }
  handleChange5 = (event) => {

    this.setState({ BirthDate: event.target.value });
  }

  componentDidMount() {
    window.onbeforeunload = function (e) {
      return "Data will be lost if you leave the page, are you sure?";
    };
  }

  render() {
    
    const First= styled.label`
 
   top: 15px;
    size: 20px;
`
   const Last= styled.label`

  position: relative;
   top: 15px;
`
   const Email= styled.label`
 
    position:relative;
     top: 30px;
`
   const Pass= styled.label`
 
   position: relative;
    top: 44px;
`
   const Birth= styled.label`
 
   position: relative;
    top: 62px ;
`
    console.log('appppp1', this)
    return (
      <div>
        <div className="App" >
          <form className="container">
            <h1>USER DETAIL FORM</h1>
           <First> <label>
              First Name:
          <input className="input" type="text" value={this.state.FirstName} onChange={this.handleChange1} />
              <br />
            </label></First>
            <Last><label >
              Last Name:
          <input className="input" type="text" value={this.state.LastName} onChange={this.handleChange2} />
              <br />
            </label></Last>
           <Email> <label>
              Email Id:
          <input className="input" type="email" value={this.state.EmailId} onChange={this.handleChange3} />
              <br />
            </label></Email>
             <Pass><label >
              Password:
          <input className="input" type="password" value={this.state.Password} onChange={this.handleChange4} />
              <br />
            </label> </Pass>
           <Birth> <label>
              BirthDate:
          <input className="input" type="text" value={this.state.BirthDate} onChange={this.handleChange5} />
              <br />
            </label></Birth>
             <Link to={{pathname:"/SaveDataPopup",state:{FirstName:this.state.FirstName,LastName:this.state.LastName,EmailId:this.state.EmailId,Password:this.state.Password,BirthDate: this.state.BirthDate}}}><input style={{ position: 'relative', top: '109px' }} type="submit" value="SAVE" /></Link>
          </form>
          
        </div>
        <div>

          {this.state.FirstName === 'Sonam' && this.state.LastName === 'Gupta' && this.state.EmailId === 'sonamgupta.1dec@gmail.com' && this.state.Password === '123456789' && this.state.BirthDate === '01/12/1994' ? (
            <Link to={{pathname:"/Dragdrop"}}><h6 style={{ position: 'relative', bottom: '268px', left: '798px' }} >GO AND UPLOAD THE FILE-></h6></Link>

          ) : (
              <Link to={{pathname:"/UnsaveDataPopup",state:{FirstName:this.state.FirstName,LastName:this.state.LastName,EmailId:this.state.EmailId,Password:this.state.Password,BirthDate:this.state.BirthDate}}}><h6 style={{ position: 'relative', bottom: '268px', left: '798px' }} >GO AND UPLOAD THE FILE-></h6></Link>
            )}

        </div>
      </div>
    );
  }
}

export default App;

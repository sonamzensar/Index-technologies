### You will need Globally installed Create React App to run this project
`npm i create-react-app -g`


# react-start-up

run npm install
run npm start

react start up

var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
	renderSelectedMember(getSelectedMembers());
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var modal1 = document.getElementById('myModal1');

// Get the button that opens the modal
var btn1 = document.getElementById("myBtn1");

// Get the <span> element that closes the modal
var span1 = document.getElementsByClassName("close1","back")[0];


// When the user clicks the button, open the modal 
btn1.onclick = function() {
    modal1.style.display = "block";
	renderSelectedMemberPopup(getSelectedMembers())
}

// When the user clicks on <span> (x), close the modal
span1.onclick = function() {
    modal1.style.display = "none";	
}

function renderSelectedMember(_selectedMembers){
	var selectedMembersContainers =  document.querySelector(".selected-members");
	var selectedMembersList = "";
	_selectedMembers.map( (member, index) => {	
			selectedMembersList += `<li>${member.Name}</li>`;			
	});
	selectedMembersContainers.innerHTML = selectedMembersList;
}
function renderSelectedMemberPopup(_selectedMembers){
	var selectedMembersContainers =  document.querySelector("#content1");
	var selectedMembersList = `<div class="member-age-list">`;
	_selectedMembers.map( (member, index) => {		
			selectedMembersList += `<div>
				<span class="member-name">${member.Name}</span>
				<span>
				<select style="
    margin-left: 4px;
    height: 21px;
    width: 134px;
">
<optgroup label="Select your age">
<option value="volvo">0-10year</option>
  <option value="volvo">10-20year</option>
  <option value="saab">20-30year</option>
  <option value="opel">30-40year</option>
  <option value="audi">40-50year</option>
  <option value="volvo">50-60year</option>
  <option value="saab">60-70year</option>
  <option value="opel">70-80year</option>
  <option value="audi">80-90year</option>
</select>
<span>
				
			</div>`;			
	});
	selectedMembersList += `</div>`;
	selectedMembersContainers.innerHTML = selectedMembersList;
}

function getSelectedMembers(){
	var selectedMembers = [];
	members.map( (member, index) => {
		if(member.checked) selectedMembers.push(member);		
	});
	return selectedMembers;
}



// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal1) {
        modal1.style.display = "none";
    }
}
var back1 = document.getElementById("back");

back1.onclick = function() {
    var x = document.getElementById("myModal1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
done = document.getElementById("closeDone");

done.onclick = function() {
    var x = document.getElementById("myModal1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
var viewquotes = document.getElementById("viewDuote");
viewquotes.onclick = function()  {
    
    if (!viewquotes.checkValidity()) {
        document.getElementById("demo").innerHTML = "please provide the complete information you would like to insure";
    } else {
        document.getElementById("demo").innerHTML = "Input OK";
    } 
} 

var members = [{
	Name: "Wife",
	Id: "1",
	age: 26,
	checked: false
}, {
	Name: "You",
	Id: "2",
	age: 24,
	checked: false
}, {
	Name: "Mother",
	Id: "3",
	age: 66,
	checked: false
}, {
	Name: "Father",
	Id: "4",
	age: 76,
	checked: false
}, {
	Name: "Son",
	Id: "5",
	age: 16,
	checked: false
},]
var root = document.querySelector("#contentCall");

var checkboxes = ""

function handleMemberSelection(id){
  
  var temp = members.map( member => {
    if(member.Id === id) member.checked = !member.checked;
    return member
  });
  members=temp
  console.log('id---->>', id, 'Members===>', members);
}

var container = document.createElement('div');
members.map( member => {
  var span = document.createElement('span');
  span.className = "member"
  
  var checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.name = member.Name;
    checkbox.value = member.Name;
    checkbox.id = member.Id;
    checkbox.checked = member.checked;
    checkbox.onchange = () => handleMemberSelection(member.Id)

  var label = document.createElement('label')
    label.htmlFor = member.Id;
    label.appendChild(document.createTextNode(member.Name));

    span.appendChild(checkbox);
    span.appendChild(label);
    container.appendChild(span);

});

function getupdatedpopup(){
var checkbox= ""
members = members.map( member => {
    var checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.name = member.Name;
    checkbox.value = member.Name;
    checkbox.id = member.Id;
    checkbox.checked = member.checked;
    checkbox.onchange = () => handleMemberSelection()
  });
}
root.appendChild(container)